import java.util.Arrays;

class Main {

	public static int[] possibleMoves(int start) {

		if ((start > 8 && start < 48) && start % 8 == 0) {
			int[] pM = { start - 15, start - 6, start + 10, start + 17 };
			return pM;
		} else if (start == 56) {
			int[] pM = { 41, 50 };
			return pM;
		} else if (start == 48) {
			int[] pM = { 33, 42, 58 };
			return pM;
		} else if (start == 8) {
			int[] pM = { 2, 18, 25 };
			return pM;
		} else if (start == 0) {
			int[] pM = { 10, 17 };
			return pM;
		}

		if ((start > 9 && start < 49) && start % 8 == 1) {
			int[] pM = { start - 17, start - 15, start - 6, start + 10, start + 15, start + 17 };
			return pM;
		} else if (start == 57) {
			int[] pM = { 40, 42, 51 };
			return pM;
		} else if (start == 49) {
			int[] pM = { 32, 34, 43, 59 };
			return pM;
		} else if (start == 9) {
			int[] pM = { 3, 19, 24, 26 };
			return pM;
		} else if (start == 1) {
			int[] pM = { 11, 16, 18 };
			return pM;
		}

		if ((start > 13 && start < 50) && ((start % 8 == 2) || (start % 8 == 3) || (start % 8 == 4) || (start % 8 == 5))) {
			int[] pM = { start - 17, start - 15, start - 10, start - 6, start + 6, start + 10, start + 15, start + 17 };
			return pM;
		} else if (start >= 10 && start <= 13) {
			int[] pM = { start - 10, start - 6, start + 6, start + 10, start + 15, start + 17 };
			return pM;
		} else if (start >= 50 && start <= 53) {
			int[] pM = { start - 17, start - 15, start - 10, start - 6, start + 6, start + 10 };
			return pM;
		} else if (start >= 58 && start <= 61) {
			int[] pM = { start - 17, start - 15, start - 10, start - 6 };
			return pM;
		} else if (start >= 2 && start <= 5) {
			int[] pM = { start + 6, start + 10, start + 15, start + 17 };
			return pM;
		}

		if (start > 14 && start < 54 && start % 8 == 6) {
			int[] pM = { start - 17, start - 15, start - 10, start + 6, start + 15, start + 17 };
			return pM;
		} else if (start == 54) {
			int[] pM = { 37, 39, 44, 60 };
			return pM;
		} else if (start == 62) {
			int[] pM = { 45, 47, 52 };
			return pM;
		} else if (start == 14) {
			int[] pM = { 4, 20, 29, 31 };
			return pM;
		} else if (start == 6) {
			int[] pM = { 12, 21, 23 };
			return pM;
		}

		if (start > 15 && start < 55 && start % 8 == 7) {
			int[] pM = { start - 17, start - 10, start + 6, start + 15 };
			return pM;
		} else if (start == 63) {
			int[] pM = { 46, 53 };
			return pM;
		} else if (start == 55) {
			int[] pM = { 38, 45, 61 };
			return pM;
		} else if (start == 15) {
			int[] pM = { 5, 21, 30 };
			return pM;
		} else if (start == 7) {
			int[] pM = { 13, 22 };
			return pM;
		}

		int[] pM = { -1 };
		return pM;
	}

	public static void main(String[] args) {
		int src = 19;
		int dest = 36;
		boolean finished = false;

		int [][][][]
	}
}